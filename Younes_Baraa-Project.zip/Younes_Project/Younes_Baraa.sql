-- --------------------------------------------------------
-- Host:                         127.0.0.1
-- Server version:               10.6.7-MariaDB - mariadb.org binary distribution
-- Server OS:                    Win64
-- HeidiSQL Version:             11.3.0.6295
-- --------------------------------------------------------

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET NAMES utf8 */;
/*!50503 SET NAMES utf8mb4 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;


-- Dumping database structure for baraa_younes
CREATE DATABASE IF NOT EXISTS `baraa_younes` /*!40100 DEFAULT CHARACTER SET utf8mb3 */;
USE `baraa_younes`;

-- Dumping structure for table baraa_younes.customers
CREATE TABLE IF NOT EXISTS `customers` (
  `CustomerID` varchar(4) NOT NULL,
  `FirstName` varchar(25) NOT NULL,
  `LastName` varchar(25) NOT NULL,
  `PhoneNumber` varchar(50) DEFAULT NULL,
  `Adress` varchar(100) DEFAULT NULL,
  `AreaCode` varchar(5) NOT NULL,
  PRIMARY KEY (`CustomerID`),
  KEY `idx_customers_areacode` (`AreaCode`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb3;

-- Dumping data for table baraa_younes.customers: ~6 rows (approximately)
/*!40000 ALTER TABLE `customers` DISABLE KEYS */;
INSERT INTO `customers` (`CustomerID`, `FirstName`, `LastName`, `PhoneNumber`, `Adress`, `AreaCode`) VALUES
	('1001', 'Sarah', 'Johnson', '555-1234', '1234 Qak.St', '100'),
	('1002', 'Mark', 'Thompsom', '555-5746', '456 Pine.St', '200'),
	('1003', 'Emily', 'Wilson', '555-111', '789 Cedar.St', '300'),
	('1004', 'Matthew', 'Davis', '555-222', '1010 Maple.St', '400'),
	('1005', 'Rachel', 'Rodriguez', '555-3333', '1313 Cherry Blossom', '500'),
	('1006', 'John', 'Smith', '555-3455', '1010 Maple Ave.', '600');
/*!40000 ALTER TABLE `customers` ENABLE KEYS */;

-- Dumping structure for table baraa_younes.deliveryboy
CREATE TABLE IF NOT EXISTS `deliveryboy` (
  `DeliveryBoyID` varchar(4) NOT NULL,
  `DeliveryBoyName` varchar(25) NOT NULL,
  `DBPhoneNumber` varchar(50) DEFAULT NULL,
  `AreaCode` varchar(5) NOT NULL,
  PRIMARY KEY (`DeliveryBoyID`),
  KEY `fk6` (`AreaCode`),
  CONSTRAINT `fk6` FOREIGN KEY (`AreaCode`) REFERENCES `customers` (`AreaCode`) ON DELETE NO ACTION ON UPDATE NO ACTION
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb3;

-- Dumping data for table baraa_younes.deliveryboy: ~6 rows (approximately)
/*!40000 ALTER TABLE `deliveryboy` DISABLE KEYS */;
INSERT INTO `deliveryboy` (`DeliveryBoyID`, `DeliveryBoyName`, `DBPhoneNumber`, `AreaCode`) VALUES
	('1001', 'Tom', '5555-1111', '100'),
	('1002', 'Sarah', '5555-7878', '200'),
	('1003', 'Farah', '5555-3456', '300'),
	('1004', 'Samer', '5555-6764', '400'),
	('1005', 'Yorgo', '5555-3321', '500'),
	('1006', 'Mike', '5555-3428', '600');
/*!40000 ALTER TABLE `deliveryboy` ENABLE KEYS */;

-- Dumping structure for table baraa_younes.menuitems
CREATE TABLE IF NOT EXISTS `menuitems` (
  `ItemID` varchar(20) NOT NULL,
  `ItemDescription` varchar(100) NOT NULL,
  `ItemType` varchar(20) NOT NULL,
  `ItemPrice` double DEFAULT NULL,
  PRIMARY KEY (`ItemID`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb3;

-- Dumping data for table baraa_younes.menuitems: ~6 rows (approximately)
/*!40000 ALTER TABLE `menuitems` DISABLE KEYS */;
INSERT INTO `menuitems` (`ItemID`, `ItemDescription`, `ItemType`, `ItemPrice`) VALUES
	('123', '	White T-Shirt', 'Clothing', 20),
	('124', 'Blue Jeans', 'Clothing', 40),
	('125', 'Black Leather Handbag', 'Accessory', 80),
	('126', '	Red High Heel Shoes', 'Footwear', 60),
	('127', 'Grey Hoodie Jacket', 'Clothing', 30),
	('128', '	Wireless Bluetooth Speaker', 'Electronics', 100);
/*!40000 ALTER TABLE `menuitems` ENABLE KEYS */;

-- Dumping structure for table baraa_younes.orders
CREATE TABLE IF NOT EXISTS `orders` (
  `OrderID` varchar(10) NOT NULL,
  `CustomerID` varchar(4) NOT NULL,
  `ItemID` varchar(20) NOT NULL,
  `DeliveryBoyID` varchar(4) NOT NULL,
  `Quantity` int(11) NOT NULL DEFAULT 0,
  `OrderDate` date NOT NULL,
  PRIMARY KEY (`OrderID`),
  KEY `FK_orders_customers` (`CustomerID`),
  KEY `fk2` (`ItemID`),
  KEY `FK_orders_deliveryboy` (`DeliveryBoyID`),
  CONSTRAINT `FK_orders_customers` FOREIGN KEY (`CustomerID`) REFERENCES `customers` (`CustomerID`) ON DELETE NO ACTION ON UPDATE NO ACTION,
  CONSTRAINT `FK_orders_deliveryboy` FOREIGN KEY (`DeliveryBoyID`) REFERENCES `deliveryboy` (`DeliveryBoyID`) ON DELETE NO ACTION ON UPDATE NO ACTION,
  CONSTRAINT `fk2` FOREIGN KEY (`ItemID`) REFERENCES `menuitems` (`ItemID`) ON DELETE NO ACTION ON UPDATE NO ACTION
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb3;

-- Dumping data for table baraa_younes.orders: ~6 rows (approximately)
/*!40000 ALTER TABLE `orders` DISABLE KEYS */;
INSERT INTO `orders` (`OrderID`, `CustomerID`, `ItemID`, `DeliveryBoyID`, `Quantity`, `OrderDate`) VALUES
	('7701', '1001', '123', '1001', 2, '2022-04-01'),
	('7702', '1002', '124', '1002', 1, '2022-04-09'),
	('7703', '1003', '125', '1003', 3, '2022-04-17'),
	('7704', '1004', '126', '1004', 5, '2022-04-24'),
	('7705', '1005', '127', '1005', 2, '2022-04-24'),
	('7706', '1006', '128', '1006', 1, '2022-05-05');
/*!40000 ALTER TABLE `orders` ENABLE KEYS */;

/*!40101 SET SQL_MODE=IFNULL(@OLD_SQL_MODE, '') */;
/*!40014 SET FOREIGN_KEY_CHECKS=IFNULL(@OLD_FOREIGN_KEY_CHECKS, 1) */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40111 SET SQL_NOTES=IFNULL(@OLD_SQL_NOTES, 1) */;
